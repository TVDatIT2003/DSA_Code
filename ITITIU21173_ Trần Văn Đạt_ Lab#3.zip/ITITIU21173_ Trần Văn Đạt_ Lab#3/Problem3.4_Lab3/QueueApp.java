import java.util.Random;

class Queue {
    private int maxSize;
    private long[] queArray;
    private int front;
    private int rear;
    private int nItems;

    public Queue(int s) {
        maxSize = s + 1;  // One extra space to distinguish between full and empty
        queArray = new long[maxSize];
        front = 0;
        rear = -1;
        nItems = 0;
    }

    public void insert(long j) {
        if (isFull()) {
            System.out.println("Queue is full. Cannot insert " + j);
            return;
        }

        if (rear == maxSize - 1) {
            rear = -1;  // Wrap around
        }
        queArray[++rear] = j;
        nItems++;
    }

    public long remove() {
        if (isEmpty()) {
            System.out.println("Queue is empty. Cannot remove.");
            return -1;
        }

        long temp = queArray[front++];
        if (front == maxSize) {
            front = 0;  // Wrap around
        }
        nItems--;
        return temp;
    }

    public long peekFront() {
        return queArray[front];
    }

    public boolean isEmpty() {
        return (nItems == 0);
    }

    public boolean isFull() {
        return (nItems == maxSize - 1);
    }

    public int size() {
        return nItems;
    }

    public void displayQueueArrayAndIndices() {
        System.out.print("Queue Array: ");
        for (long item : queArray) {
            System.out.print(item + " ");
        }
        System.out.println("\nFront Index: " + front + ", Rear Index: " + rear);
    }

    public void displayQueue() {
        System.out.print("Queue: ");
        int tempFront = front;
        for (int i = 0; i < nItems; i++) {
            System.out.print(queArray[tempFront % maxSize] + " ");
            tempFront++;
        }
        System.out.println();
    }

    public void removeAfterN(int n) {
        if (n <= nItems) {
            for (int i = 0; i < n; i++) {
                remove();
            }
        } else {
            System.out.println("Cannot remove " + n + " items. Queue has only " + nItems + " items.");
        }
    }

    // Simulate a queue of customers being served for a random amount of time
    public void simulateCustomerQueue(int simulationTime, int maxServiceTime, double arrivalRate) {
        Random rand = new Random();
        int time = 0;

        while (time < simulationTime) {
            if (rand.nextDouble() < arrivalRate) {
                insert(time);  // Enqueue customer
                System.out.println("Customer arrived at time " + time);
            }

            if (!isEmpty()) {
                long customer = remove();
                System.out.println("Customer served at time " + time + ". Service time: " + customer);
                time += customer;  // Increment time by service time
            }

            time++;
        }
    }
}

class QueueApp {
    public static void main(String[] args) {
        Queue theQueue = new Queue(5);  // queue holds 5 items

        theQueue.insert(10);
        theQueue.insert(20);
        theQueue.insert(30);

        // Display array, queue, and indices
        theQueue.displayQueueArrayAndIndices();
        theQueue.displayQueue();

        theQueue.remove();  // Remove one item
        theQueue.remove();  // Remove one more item

        // Display array, queue, and indices after removal
        theQueue.displayQueueArrayAndIndices();
        theQueue.displayQueue();

        theQueue.insert(40);
        theQueue.insert(50);
        theQueue.insert(60);

        // Display array, queue, and indices after insertion
        theQueue.displayQueueArrayAndIndices();
        theQueue.displayQueue();

        theQueue.removeAfterN(2);  // Remove 2 items after 2 calls

        // Display array, queue, and indices after removeAfterN
        theQueue.displayQueueArrayAndIndices();
        theQueue.displayQueue();

        // Simulate a customer queue
        theQueue.simulateCustomerQueue(20, 5, 0.3);
    }
}
