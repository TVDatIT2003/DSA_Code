class PriorityQ {
    private int maxSize;
    private long[] queArray;
    private int nItems;

    public PriorityQ(int s) {
        maxSize = s;
        queArray = new long[maxSize];
        nItems = 0;
    }

    public void insert(long item) {
        if (isFull()) {
            System.out.println("Queue is full. Cannot insert " + item);
            return;
        }

        queArray[nItems++] = item;
    }

    public long remove() {
        int minIndex = 0;
        for (int i = 1; i < nItems; i++) {
            if (queArray[i] < queArray[minIndex]) {
                minIndex = i;
            }
        }

        long minValue = queArray[minIndex];

        for (int i = minIndex; i < nItems - 1; i++) {
            queArray[i] = queArray[i + 1];
        }

        nItems--;
        return minValue;
    }

    public long peekMin() {
        return queArray[nItems - 1];
    }

    public boolean isEmpty() {
        return (nItems == 0);
    }

    public boolean isFull() {
        return (nItems == maxSize);
    }

    public void displayQueue() {
        System.out.print("Queue: ");
        for (int i = nItems - 1; i >= 0; i--) {
            System.out.print(queArray[i] + " ");
        }
        System.out.println();
    }
}

class PriorityQApp {
    public static void main(String[] args) {
        PriorityQ thePQ = new PriorityQ(5);
        thePQ.insert(30);
        thePQ.insert(50);
        thePQ.insert(10);
        thePQ.insert(40);
        thePQ.insert(20);

        // Display initial queue
        thePQ.displayQueue();

        while (!thePQ.isEmpty()) {
            // Display queue before removing
            thePQ.displayQueue();

            long item = thePQ.remove();
            System.out.println("Removed: " + item);
        }
    }
}
