import java.util.Scanner;
import java.util.Stack;

public class Convert {
    static Stack<Integer> res = new Stack<Integer>();

    static void concatenate(Stack<Integer>s1, Stack<Integer>s2){
        // Push contents of both stacks in result
        while (s1.size() != 0) {
            res.push(s1.peek());
            s1.pop();
        }
         
        while (s2.size() != 0) {
            res.push(s2.peek());
            s2.pop();
        }
    }

    static boolean identical(Stack<String> stack1, Stack<String> stack2){
    boolean check = true;
 
    // Check if size of both stacks are same
    if (stack1.size() != stack2.size()){
        check = false;
        return check;
    }
 
    // Until the stacks are not empty
    // compare top of both stacks
    while (stack1.empty() == false){
        // If the top elements of both stacks
        // are same
        if (stack1.peek() == stack2.peek()){
            // Pop top of both stacks
            stack1.pop();
            stack2.pop();
        }
        else{
            // Otherwise, set flag to false
            check = false;
            break;
        }
    }
    return check;
}
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        
        Stack stack = new Stack<>();

        //Convert a decimal number and convert it to octal form
        while (n > 0) {
            stack.push(n%8);
            n /= 8;
        }
        while (!stack.empty()) {
            System.out.print(stack.pop());
        }

        //Concatenate two stacks
        System.out.println("");
        System.out.println("");

        Stack<Integer> s1 = new Stack<Integer>();
        Stack<Integer> s2 = new Stack<Integer>();
            //Create content for stack
        s1.push(55);
        s1.push(74);
        s1.push(19);
        s1.push(48);

        s2.push(46);
        s2.push(23);
        s2.push(106);

        concatenate(s1, s2);
        System.out.println("Concatenate stack:");
        while (res.size() != 0) {
            System.out.print(res.peek()+ " ");
            res.pop();
        }

        // Determine if the contents of one stack are identical to that of another
        System.out.println("");
        System.err.println("");
            // Creating stacks
        Stack<String> stack1 = new Stack<String>();
        Stack<String> stack2 = new Stack<String>();
        // Inserting elements to stack1
    stack1.push("Welcome");
    stack1.push("to");
    stack1.push("my");
    stack1.push("DSA");
    stack1.push("class");
 
    // Inserting elements to stack2
    stack2.push("Welcome");
    stack2.push("to");
    stack2.push("my");
    stack2.push("DSA");
    stack2.push("class");
 
    if (identical(stack1, stack2))
        System.out.println("Stacks are Same");
    else
        System.out.println("Stacks are not Same");
    }
}
