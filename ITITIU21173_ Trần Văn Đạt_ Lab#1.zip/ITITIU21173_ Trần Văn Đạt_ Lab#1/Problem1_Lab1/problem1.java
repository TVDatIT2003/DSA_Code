import java.util.Scanner;
import java.lang.Math;
import java.io.*;

public class problem1 {
    public static void main(String[] args)throws IOException {
        int n;
        int digits[] = new int[1000];
        double result = 0;
        double sum = 0 ;

        //Input number of array
        //Ex1.1
        System.out.println("Ex1.1");
        Scanner scanner = new Scanner(System.in);
        n = scanner.nextInt();
        
        //Input value for array
        for (int i = 0; i < n; i++) {
            digits[i] = scanner.nextInt();
        }

        //Convert value
        for (int i = 0; i < n; i++) {
            result = result + digits[i]*(Math.pow(10, n-1-i));
        }

        //Print result
        System.out.println(result);

        //Ex1.2
        System.out.println("Ex1.2");
        n = scanner.nextInt();
        
        //Input value for array
        for (int i = 0; i < n; i++) {
            digits[i] = scanner.nextInt();
        }

        //Caculate median
        for (int i = 0; i < n; i++) {
            sum +=  digits[i];
        }
        result = sum / n;

        //Print result
        System.out.println(result);

        //Ex1.3
        System.out.println("Ex1.3");
        int gap[] = new int[1000];
        n = scanner.nextInt();
        
        //Input value for array
        for (int i = 0; i < n; i++) {
            digits[i] = scanner.nextInt();
        }
        //Find min-gap
        if (n+1 < 2) {
            System.out.println("Min-gap = 0");
        } else{
            for (int i = 0; i < n; i++) {
                gap[i] = Math.abs(digits[i+1] - digits[i]);
            }
            int min = gap[0];
            for (int i = 0; i < n; i++) {
                if(gap[i]< min){
                    min = gap[i];
                    
                }       
            } 
            System.out.println("Min-gap = " + min);       
        }

        //Ex4
        System.out.println("Ex1.4");

        bankAccount ba1 = new bankAccount(100.00); // create acct

        System.out.print("Before transactions, ");
        System.out.println("balance = " + ba1.getBalance());                         // display balance

        ba1.deposit(74.35);                    // make deposit
        ba1.withdraw(20.00);                   // make withdrawal

        System.out.print("After transactions, ");
        System.out.println("balance = " + ba1.getBalance());                         // display balance

        //Ex1.5
        System.err.println("Ex1.5");
        String first_name, last_name;
        int grade, total=0, count=0;
        double average;
        Scanner fileInput = new Scanner(new File("students.txt"));
        while (fileInput.hasNext())
        {
            first_name = fileInput.next();
            last_name = fileInput.next();
            grade = fileInput.nextInt();
            
            Student st = new Student(first_name, last_name, grade);
            
            System.out.println(st);
            total = total + grade; 
            count++;
        }
        average = (double)total/count;
        System.out.println("There are " + count + " students with average grade " + average);
        
    }
}
