import java.util.*;

// Node class represents a vertex in the graph
class Node {
    private String label;

    public Node(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    @Override
    public String toString() {
        return label;
    }
}

// Edge class represents an edge between two nodes in the graph
class Edge {
    private Node start;
    private Node end;
    private int weight;

    public Edge(Node start, Node end, int weight) {
        this.start = start;
        this.end = end;
        this.weight = weight;
    }

    public Node getStart() {
        return start;
    }

    public Node getEnd() {
        return end;
    }

    public int getWeight() {
        return weight;
    }
    @Override
    public String toString() {
        return start + " -> " + end + " (Weight: " + weight + ")";
    }
}

// Graph class represents a graph using an adjacency list
class Graph {
    private Map<Node, List<Node>> adjacencyList;

    public Graph() {
        this.adjacencyList = new HashMap<>();
    }

    public void addNode(Node node) {
        adjacencyList.put(node, new ArrayList<>());
    }

    public void addEdge(Edge edge) {
        Node start = edge.getStart();
        Node end = edge.getEnd();

        if (!adjacencyList.containsKey(start) || !adjacencyList.containsKey(end)) {
            throw new IllegalArgumentException("Nodes in the edge must be part of the graph.");
        }

        adjacencyList.get(start).add(end);
        adjacencyList.get(end).add(start);
    }

    public List<Node> getNeighbors(Node node) {
        return adjacencyList.getOrDefault(node, Collections.emptyList());
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Node node : adjacencyList.keySet()) {
            sb.append(node).append(" -> ").append(adjacencyList.get(node)).append("\n");
        }
        return sb.toString();
    }
}

// MapApp class for testing the Graph implementation
public class MapApp {
    public static void main(String[] args) {
        Graph graph = new Graph();

        Node a = new Node("A");
        Node b = new Node("B");
        Node c = new Node("C");
        Node d = new Node("D");
        Node e = new Node("E");
        Node f = new Node("F");
        Node g = new Node("G");
        Node h = new Node("H");
        Node i = new Node("I");
        Node j = new Node("J");
        Node k = new Node("K");
        Node l = new Node("L");
        Node two = new Node("2");

        graph.addNode(a);
        graph.addNode(b);
        graph.addNode(c);
        graph.addNode(d);
        graph.addNode(e);
        graph.addNode(f);
        graph.addNode(g);
        graph.addNode(h);
        graph.addNode(i);
        graph.addNode(j);
        graph.addNode(k);
        graph.addNode(l);
        graph.addNode(two);

        Edge ab = new Edge(a, b, 6);
        Edge a2 = new Edge(a, two, 10);
        Edge b2 = new Edge(b, two, 12);
        Edge bc = new Edge(b, c, 11);
        Edge bd = new Edge(b, d, 14);
        Edge c2 = new Edge(c, two, 12);
        Edge cf = new Edge(c, f, 3);
        Edge ce = new Edge(c, e, 6);
        Edge de = new Edge(d, e, 4);
        Edge dh = new Edge(d, h, 6);
        Edge dk = new Edge(d, k, 15);
        Edge eh = new Edge(e, h, 12);
        Edge f2 = new Edge(f, two, 8);
        Edge fi = new Edge(f, i, 6);
        Edge fh = new Edge(f, h, 16);
        Edge g2 = new Edge(g, two, 16);
        Edge gi = new Edge(g, i, 8);
        Edge hi = new Edge(h, i, 13);
        Edge hl = new Edge(h, l, 18);
        Edge hk = new Edge(h, k, 12);
        Edge il = new Edge(i, l, 17);
        Edge jk = new Edge(j, k, 9);
        Edge jl = new Edge(j, l, 20);

        graph.addEdge(ab);
        graph.addEdge(a2);
        graph.addEdge(b2);
        graph.addEdge(bc);
        graph.addEdge(bd);
        graph.addEdge(c2);
        graph.addEdge(cf);
        graph.addEdge(ce);
        graph.addEdge(de);
        graph.addEdge(dh);
        graph.addEdge(dk);
        graph.addEdge(eh);
        graph.addEdge(f2);
        graph.addEdge(fi);
        graph.addEdge(fh);
        graph.addEdge(g2);
        graph.addEdge(gi);
        graph.addEdge(hi);
        graph.addEdge(hl);
        graph.addEdge(hk);
        graph.addEdge(il);
        graph.addEdge(jk);
        graph.addEdge(jl);


        System.out.println("Graph Representation:");
        System.out.println(graph);

        System.out.println("Neighbors of Node A: " + graph.getNeighbors(a));
        System.out.println("Neighbors of Node B: " + graph.getNeighbors(b));
        System.out.println("Neighbors of Node C: " + graph.getNeighbors(c));
        System.out.println("Neighbors of Node D: " + graph.getNeighbors(d));
        System.out.println("Neighbors of Node E: " + graph.getNeighbors(e));
        System.out.println("Neighbors of Node F: " + graph.getNeighbors(f));
        System.out.println("Neighbors of Node G: " + graph.getNeighbors(g));
        System.out.println("Neighbors of Node H: " + graph.getNeighbors(h));
        System.out.println("Neighbors of Node I: " + graph.getNeighbors(i));
        System.out.println("Neighbors of Node J: " + graph.getNeighbors(j));
        System.out.println("Neighbors of Node K: " + graph.getNeighbors(k));
        System.out.println("Neighbors of Node L: " + graph.getNeighbors(l));
        System.out.println("Neighbors of Node 2: " + graph.getNeighbors(two));
    }
}