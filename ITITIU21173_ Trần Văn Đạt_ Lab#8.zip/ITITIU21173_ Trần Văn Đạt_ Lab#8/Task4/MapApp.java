import java.util.*;

// Node class represents a vertex in the graph
class Node {
    private String label;

    public Node(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    @Override
    public String toString() {
        return label;
    }
}

// Edge class represents an edge between two nodes in the graph
class Edge {
    private Node start;
    private Node end;
    private int weight;

    public Edge(Node start, Node end, int weight) {
        this.start = start;
        this.end = end;
        this.weight = weight;
    }

    public Node getStart() {
        return start;
    }

    public Node getEnd() {
        return end;
    }

    public int getWeight() {
        return weight;
    }
    @Override
    public String toString() {
        return start + " -> " + end + " (Weight: " + weight + ")";
    }
}

// Graph class represents a graph using an adjacency list
class Graph {
    private Map<Node, List<Node>> adjacencyList;
    private List<Edge> edges;


    public Graph() {
        this.adjacencyList = new HashMap<>();
        this.edges = new ArrayList<>();

    }

    public void addNode(Node node) {
        adjacencyList.put(node, new ArrayList<>());
    }

    public void addEdge(Edge edge) {
        Node start = edge.getStart();
        Node end = edge.getEnd();

        if (!adjacencyList.containsKey(start) || !adjacencyList.containsKey(end)) {
            throw new IllegalArgumentException("Nodes in the edge must be part of the graph.");
        }

        adjacencyList.get(start).add(end);
        adjacencyList.get(end).add(start);

        edges.add(edge);
    }
    public List<Edge> getEdges() {
        return edges;
    }
    public List<Node> getNeighbors(Node node) {
        return adjacencyList.getOrDefault(node, Collections.emptyList());
    }

     public List<Node> getNodes() {
        return new ArrayList<>(adjacencyList.keySet());
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Node node : adjacencyList.keySet()) {
            sb.append(node).append(" -> ").append(adjacencyList.get(node)).append("\n");
        }
        return sb.toString();
    }

    public int countPathsDFS(Node start, Node end) {
        Set<Node> visited = new HashSet<>();
        return countPathsDFSHelper(start, end, visited);
    }

    private int countPathsDFSHelper(Node current, Node end, Set<Node> visited) {
        if (current.equals(end)) {
            return 1;
        }

        visited.add(current);
        int paths = 0;

        for (Node neighbor : getNeighbors(current)) {
            if (!visited.contains(neighbor)) {
                paths += countPathsDFSHelper(neighbor, end, visited);
            }
        }

        visited.remove(current);
        return paths;
    }

    public int countPathsBFS(Node start, Node end) {
        Queue<Node> queue = new LinkedList<>();
        Map<Node, Integer> pathCount = new HashMap<>();
    
        queue.offer(start);
        pathCount.put(start, 1);

        while (!queue.isEmpty()) {
            Node current = queue.poll();

            for (Node neighbor : getNeighbors(current)) {
                if (!pathCount.containsKey(neighbor)) {
                    queue.offer(neighbor);
                    pathCount.put(neighbor, pathCount.get(current));
                } else {
                    pathCount.put(neighbor, pathCount.get(neighbor) + pathCount.get(current));
                }
            }
        }

        return pathCount.getOrDefault(end, 0);
    }

    public List<List<Node>> findAllPathsDFS(Node start, Node end) {
        List<List<Node>> allPaths = new ArrayList<>();
        List<Node> currentPath = new ArrayList<>();
        Set<Node> visited = new HashSet<>();

        findAllPathsDFSHelper(start, end, visited, currentPath, allPaths);

        return allPaths;
    }

    private void findAllPathsDFSHelper(Node current, Node end, Set<Node> visited, 
                                   List<Node> currentPath, List<List<Node>> allPaths) {
        visited.add(current);
        currentPath.add(current);

        if (current.equals(end)) {
            allPaths.add(new ArrayList<>(currentPath));
        } else {
            for (Node neighbor : getNeighbors(current)) {
                if (!visited.contains(neighbor)) {
                    findAllPathsDFSHelper(neighbor, end, visited, currentPath, allPaths);
            }
            }
        }

        visited.remove(current);
        currentPath.remove(current);
    }

    public void printPathsInfo(List<List<Node>> paths) {
        for (List<Node> path : paths) {
            int cost = calculateCost(path); 
            System.out.println("Path: " + path + ", Cost: " + cost);
        }
    }

    private int calculateCost(List<Node> path) {
        int cost = 0;
        for (int i = 0; i < path.size() - 1; i++) {
            Node current = path.get(i);
            Node next = path.get(i + 1);
  
            List<Node> neighbors = adjacencyList.get(current);
            for (Node neighbor : neighbors) {
                if (neighbor.equals(next)) {
                    cost += getWeight(current, neighbor);
                    break;
                }
            }
        }
       return cost;
    }

    private int getWeight(Node start, Node end) {
        Edge edge = findEdge(start, end);
        return edge != null ? edge.getWeight() : 0;
    }

    private Edge findEdge(Node start, Node end) {
    
        List<Node> neighbors = adjacencyList.get(start);
        for (Node neighbor : neighbors) {
            if (neighbor.equals(end)) {
                return new Edge(start, end, 0); 
            }
        }
        return null;
    }

}

// MapApp class for testing the Graph implementation
public class MapApp {
    private Graph graph;
    private List<Edge> edges;

    public MapApp() {
        this.graph = new Graph();
        this.edges = new ArrayList<>();
    }
    public void addEdge(Edge edge) {
        edges.add(edge);
        graph.addEdge(edge);
    }
    public List<Edge> getEdges() {
        return edges;
    }
    public static void main(String[] args) {
        Graph graph = new Graph();

        Node a = new Node("A");
        Node b = new Node("B");
        Node c = new Node("C");
        Node d = new Node("D");
        Node e = new Node("E");
        Node f = new Node("F");
        Node g = new Node("G");
        Node h = new Node("H");
        Node i = new Node("I");
        Node j = new Node("J");
        Node k = new Node("K");
        Node l = new Node("L");
        Node two = new Node("2");

        graph.addNode(a);
        graph.addNode(b);
        graph.addNode(c);
        graph.addNode(d);
        graph.addNode(e);
        graph.addNode(f);
        graph.addNode(g);
        graph.addNode(h);
        graph.addNode(i);
        graph.addNode(j);
        graph.addNode(k);
        graph.addNode(l);
        graph.addNode(two);

        Edge ab = new Edge(a, b, 6);
        Edge a2 = new Edge(a, two, 10);
        Edge b2 = new Edge(b, two, 12);
        Edge bc = new Edge(b, c, 11);
        Edge bd = new Edge(b, d, 14);
        Edge c2 = new Edge(c, two, 12);
        Edge cf = new Edge(c, f, 3);
        Edge ce = new Edge(c, e, 6);
        Edge de = new Edge(d, e, 4);
        Edge dh = new Edge(d, h, 6);
        Edge dk = new Edge(d, k, 15);
        Edge eh = new Edge(e, h, 12);
        Edge f2 = new Edge(f, two, 8);
        Edge fi = new Edge(f, i, 6);
        Edge fh = new Edge(f, h, 16);
        Edge g2 = new Edge(g, two, 16);
        Edge gi = new Edge(g, i, 8);
        Edge hi = new Edge(h, i, 13);
        Edge hl = new Edge(h, l, 18);
        Edge hk = new Edge(h, k, 12);
        Edge il = new Edge(i, l, 17);
        Edge jk = new Edge(j, k, 9);
        Edge jl = new Edge(j, l, 20);

        graph.addEdge(ab);
        graph.addEdge(a2);
        graph.addEdge(b2);
        graph.addEdge(bc);
        graph.addEdge(bd);
        graph.addEdge(c2);
        graph.addEdge(cf);
        graph.addEdge(ce);
        graph.addEdge(de);
        graph.addEdge(dh);
        graph.addEdge(dk);
        graph.addEdge(eh);
        graph.addEdge(f2);
        graph.addEdge(fi);
        graph.addEdge(fh);
        graph.addEdge(g2);
        graph.addEdge(gi);
        graph.addEdge(hi);
        graph.addEdge(hl);
        graph.addEdge(hk);
        graph.addEdge(il);
        graph.addEdge(jk);
        graph.addEdge(jl);

        
        Node startNode = a; // Starting node
        Node endNode = k;   // Ending node

        System.out.println("Paths from " + startNode + " to " + endNode + ":");

        // Find all paths
        List<List<Edge>> allPaths = findAllPaths(graph, startNode, endNode);

        // Print all paths with their lengths and total weights
        printPathsInfo(allPaths);
    }

    // DFS to find all paths between two nodes in a graph
    private static List<List<Edge>> findAllPaths(Graph graph, Node start, Node end) {
        List<List<Edge>> allPaths = new ArrayList<>();
        Stack<Edge> currentPath = new Stack<>();
        boolean[] visited = new boolean[graph.getNodes().size()];

        findAllPathsDFS(graph, start, end, visited, currentPath, allPaths);

        return allPaths;
    }

    private static void findAllPathsDFS(
            Graph graph,
            Node currentNode,
            Node endNode,
            boolean[] visited,
            Stack<Edge> currentPath,
            List<List<Edge>> allPaths
    ) {
        visited[graph.getNodes().indexOf(currentNode)] = true;

        List<Node> neighbors = graph.getNeighbors(currentNode);
        for (Node neighbor : neighbors) {
            if (!visited[graph.getNodes().indexOf(neighbor)]) {
                Edge edge = findEdge(graph.getEdges(), currentNode, neighbor);
                currentPath.push(edge);

                if (neighbor.equals(endNode)) {
                    allPaths.add(new ArrayList<>(currentPath));
                } else {
                    findAllPathsDFS(graph, neighbor, endNode, visited, currentPath, allPaths);
                }

                currentPath.pop();
            }
        }

        visited[graph.getNodes().indexOf(currentNode)] = false;
    }

    // Find an edge between two nodes
    private static Edge findEdge(List<Edge> edges, Node start, Node end) {
        for (Edge edge : edges) {
            if ((edge.getStart().equals(start) && edge.getEnd().equals(end)) ||
                    (edge.getStart().equals(end) && edge.getEnd().equals(start))) {
                return edge;
            }
        }
        return null;
    }

    // Print information about paths, their lengths, and total weights
    private static void printPathsInfo(List<List<Edge>> paths) {
        if (paths.isEmpty()) {
            System.out.println("No paths found.");
        } else {
            int minLength = Integer.MAX_VALUE;
            int maxLength = Integer.MIN_VALUE;

            List<Edge> shortestPath = null;
            List<Edge> longestPath = null;

            for (List<Edge> path : paths) {
                int pathLength = path.size();
                int totalWeight = calculateTotalWeight(path);

                if (pathLength < minLength) {
                    minLength = pathLength;
                    shortestPath = path;
                }

                if (pathLength > maxLength) {
                    maxLength = pathLength;
                    longestPath = path;
                }

                System.out.println("Path: " + path + " | Length: " + pathLength + " | Total Weight: " + totalWeight);
            }

            System.out.println("\nShortest Path: " + shortestPath + " | Length: " + minLength +
                    " | Total Weight: " + calculateTotalWeight(shortestPath));

            System.out.println("Longest Path: " + longestPath + " | Length: " + maxLength +
                    " | Total Weight: " + calculateTotalWeight(longestPath));
        }
    }

    // Calculate the total weight of a path
    private static int calculateTotalWeight(List<Edge> path) {
        int totalWeight = 0;
        for (Edge edge : path) {
            totalWeight += edge.getWeight();
        }
        return totalWeight;
        
    }
}