import java.util.Scanner;

public class Sum {
    static double sum(int n) // n>=1
    {
    if (n == 1)
        return 1;
    return ((double)1/n) + sum(n-1);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Input value of n:");
        int n = scanner.nextInt();
        System.out.println("Sum");
        System.out.println(sum(n));
    }
}
