import java.util.*;

public class MinimumElement {
    //return the minimum element in a[]
    static int findmin(int a[], int n){
        if (n == 1) {
            return a[0];  
        }
        return Math.min(a[n-1], findmin(a, n-1));
    }

    static int findsum(int a[], int n){
        if (n == 1) {
            return a[0];
        }
        return a[n-1] + findsum(a, n-1);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input Size of array");
        int n = scanner.nextInt();
        int array[] = new int[n];
        n = array.length;

        //Function calling
        System.out.println("Input Data of Array: ");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }
        System.out.println("Mininmum element:" + findmin(array, n));
        System.out.println("Sum: " + findsum(array, n));

    }
}
