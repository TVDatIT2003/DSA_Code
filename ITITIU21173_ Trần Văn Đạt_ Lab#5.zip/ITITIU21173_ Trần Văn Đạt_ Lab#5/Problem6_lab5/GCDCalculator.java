import java.util.*;

public class GCDCalculator {
    static int GCD(int p, int q){
        if (q == 0) {
            return p;
        }
        return GCD(q, p % q);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input two numbers:");
        int p = scanner.nextInt();
        int q = scanner.nextInt();
        System.out.println("The GCD of " + p + " and " + q + " is : " + GCD(p, q));
    }    
}
