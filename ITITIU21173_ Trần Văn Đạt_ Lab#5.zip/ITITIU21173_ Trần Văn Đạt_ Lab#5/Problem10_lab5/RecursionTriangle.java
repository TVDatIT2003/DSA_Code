public class RecursionTriangle  {
    
}
