import java.util.*;

public class GetSubsets {
    static void subsets(String str, int index, String curr){
        int n = str.length();

        if (index == n) {
            return;
        }

        //First current subset
        System.out.println(curr);

        //Remaining character
        for (int i = index + 1; i < n; i++) {
            curr += str.charAt(i);
            subsets(str, i, curr);
            curr = curr.substring(0, curr.length() - 1);
        }
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input String: ");
        String str = scanner.nextLine();

        System.out.println("All subsets: ");
        subsets(str, -1, "");
    }
}
